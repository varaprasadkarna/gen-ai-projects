import streamlit as st
import requests
import cohere

# Initialize Cohere API
cohere_api_key = 'w0MZoCA0uGdMpLYoE6URut4S8FJEgGB1wRWOTYXj'  # Replace with your Cohere API key
co = cohere.Client(cohere_api_key)

# ElevenLabs API key and endpoint
elevenlabs_api_key = 'sk_c4f696783e0c57b2fc99389635bd26f39e3162be359d85c1'  # Replace with your ElevenLabs API key
elevenlabs_url = 'https://api.elevenlabs.io/v1/text-to-speech'

# Function to generate podcast script using Cohere
def generate_podcast_script(prompt):
    response = co.generate(
        model='command',  # Choose a model size
        prompt=prompt,
        max_tokens=500  # You can adjust the length of the response here
    )
    return response.text

# Function to convert text to speech using ElevenLabs API
def text_to_speech(text, voice='en_us_male'):
    headers = {
        'Authorization': f'Bearer {elevenlabs_api_key}',
        'Content-Type': 'application/json'
    }
    
    data = {
        'text': text,
        'voice': voice,
        'speed': 1.0,
        'volume': 1.0,
        'pitch': 1.0
    }
    
    response = requests.post(elevenlabs_url, headers=headers, json=data)
    if response.status_code == 200:
        audio_url = response.json().get('audio_url')
        return audio_url
    else:
        return "Error generating speech."

# Streamlit UI
st.title('Podcast Generator with Cohere & ElevenLabs')

# Get user input for podcast generation
topic = st.text_input('Enter a Topic for the Podcast')

# Button to generate and listen to podcast
if st.button('Generate Podcast'):
    if topic:
        # Generate the script using Cohere
        podcast_script = generate_podcast_script(f'Write a podcast script about {topic}')
        
        # Display generated script
        st.subheader('Generated Podcast Script:')
        st.write(podcast_script)
        
        # Generate the audio using ElevenLabs
        audio_url = text_to_speech(podcast_script)
        
        if audio_url != "Error generating speech.":
            st.audio(audio_url, format='audio/mp3')
        else:
            st.error("Failed to generate audio.")
    else:
        st.error("Please enter a topic for the podcast.")
